package com.example.SpringBootTestDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
