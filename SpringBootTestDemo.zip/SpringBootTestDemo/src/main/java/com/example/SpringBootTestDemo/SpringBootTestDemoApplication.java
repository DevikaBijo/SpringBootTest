package com.example.SpringBootTestDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTestDemoApplication.class, args);
	}

}
